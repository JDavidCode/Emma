:mod:`investpy.certificates`
============================

.. automodule:: investpy.certificates
   :special-members:
   :exclude-members:
   :members: