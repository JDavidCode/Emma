:mod:`investpy.commodities`
===========================

.. automodule:: investpy.commodities
   :special-members:
   :exclude-members:
   :members: