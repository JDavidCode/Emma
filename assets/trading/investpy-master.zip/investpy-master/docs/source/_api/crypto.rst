:mod:`investpy.crypto`
======================

.. automodule:: investpy.crypto
   :special-members:
   :exclude-members:
   :members: