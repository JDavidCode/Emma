:mod:`investpy.currency_crosses`
================================

.. automodule:: investpy.currency_crosses
   :special-members:
   :exclude-members:
   :members: