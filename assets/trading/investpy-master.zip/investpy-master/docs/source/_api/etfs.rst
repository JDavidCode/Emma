:mod:`investpy.etfs`
====================

.. automodule:: investpy.etfs
   :special-members:
   :exclude-members:
   :members: