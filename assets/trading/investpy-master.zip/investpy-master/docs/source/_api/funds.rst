:mod:`investpy.funds`
=====================

.. automodule:: investpy.funds
   :special-members:
   :exclude-members:
   :members: