:mod:`investpy.indices`
=======================

.. automodule:: investpy.indices
   :special-members:
   :exclude-members:
   :members: