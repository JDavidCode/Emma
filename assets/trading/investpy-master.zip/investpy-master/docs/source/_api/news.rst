:mod:`investpy.news`
====================

.. automodule:: investpy.news
   :special-members:
   :exclude-members:
   :members: