:mod:`investpy.search`
======================

.. automodule:: investpy.search
   :special-members:
   :exclude-members:
   :members:

.. autoclass:: investpy.utils.search_obj.SearchObj
   :special-members:
   :exclude-members:
   :members:
