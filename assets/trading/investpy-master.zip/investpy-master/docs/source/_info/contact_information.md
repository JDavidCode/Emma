## 👨‍💻 Contact Information

You can contact me at any of my social network profiles:

- 💼 LinkedIn: https://linkedin.com/in/alvarobartt
- 🐦 Twitter: https://twitter.com/alvarobartt
- 🐙 GitHub: https://github.com/alvarobartt

Or via email at alvarobartt@yahoo.com, even though this last one is not recommended
as mentioned in the FAQs.
