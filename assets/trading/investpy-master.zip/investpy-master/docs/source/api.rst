API Reference
=============

.. toctree::
   :maxdepth: 2

   _api/stocks.rst
   _api/funds.rst
   _api/etfs.rst
   _api/indices.rst
   _api/currency_crosses.rst
   _api/bonds.rst
   _api/commodities.rst
   _api/certificates.rst
   _api/crypto.rst
   _api/news.rst
   _api/technical.rst
   _api/search.rst
